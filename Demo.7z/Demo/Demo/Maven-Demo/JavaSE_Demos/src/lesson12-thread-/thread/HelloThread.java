package com.javatraining.lesson12.thread;

public class HelloThread extends Thread {

public void run(){
	
	
	System.out.println("Hello ..  Welcome to Capgemini.");
	
}

}
