package com.javatraining.lesson3.control;

public class SwitchExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
	    switch (i) {

	    case 0:
	      System.out.println("i is 0");
	    case 1:
	      System.out.println("i is 1");
	    case 2:
	      System.out.println("i is 2");
	    default:
	      System.out.println("Free flowing switch example!");

	    }
	}
}
